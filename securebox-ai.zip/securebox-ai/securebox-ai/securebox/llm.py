"""AI summariser. Uses an open-weight model of 8B parameters or fewer.

Providers (env LLM_PROVIDER):
  ollama - local model, default qwen3:4b  (4B parameters)
  groq   - hosted, default llama-3.1-8b-instant (8B parameters)
  none   - skip the model and use the rule-based text only

If the model is unreachable we fall back to a template summary and say so
(`ok: False`, `provider: "fallback"`) - the UI never pretends the AI ran.
"""
import os
import re
from datetime import datetime

import requests

from .engine import RECOMMENDATION

DEFAULTS = {
    "ollama": {"model": "qwen3:4b", "params": "4B"},
    "groq": {"model": "llama-3.1-8b-instant", "params": "8B"},
}


def config():
    provider = os.getenv("LLM_PROVIDER", "ollama").lower()
    d = DEFAULTS.get(provider, {"model": "-", "params": "-"})
    return {
        "provider": provider,
        "model": os.getenv("LLM_MODEL", d["model"]),
        "params": os.getenv("LLM_PARAMS", d["params"]),
    }


def _timeline(events, limit=40):
    lines = []
    for e in events[-limit:]:
        t = datetime.fromtimestamp(e["ts"]).strftime("%H:%M:%S")
        lines.append(f"[{t}] {e['type']} - {e['detail']}")
    return "\n".join(lines)


def build_prompt(events, analysis):
    flagged = "\n".join(
        f"- {f['title']} ({f['severity']}): {f['why']}" for f in analysis["findings"]
    ) or "- none"
    return (
        "You are a physical-security analyst for a locked box that protects a "
        "sensitive computer. Below is the sensor event log and the findings "
        "from a rule engine. Use ONLY the events listed; do not invent any.\n\n"
        f"EVENT LOG:\n{_timeline(events)}\n\n"
        f"RULE FINDINGS (risk {analysis['score']}/100, {analysis['level']}):\n{flagged}\n\n"
        "Reply in exactly three labelled lines, under 110 words total:\n"
        "SUMMARY: one or two sentences describing the sequence in plain English.\n"
        "ASSESSMENT: whether this looks suspicious and why.\n"
        "ACTION: the single most useful next step."
    )


def fallback_summary(events, analysis):
    if not events:
        return "SUMMARY: No events recorded yet.\nASSESSMENT: Nothing to assess.\nACTION: None."
    titles = ", ".join(f["title"].lower() for f in analysis["findings"]) or "no suspicious patterns"
    return (
        f"SUMMARY: {len(events)} events recorded; rule engine found {titles}.\n"
        f"ASSESSMENT: Risk level is {analysis['level']} ({analysis['score']}/100).\n"
        f"ACTION: {RECOMMENDATION[analysis['level']]}"
    )


def _clean(text):
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    return text.strip()


def _call_ollama(cfg, prompt):
    url = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
    r = requests.post(
        f"{url}/api/chat",
        json={
            "model": cfg["model"],
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "think": False,
            "options": {"temperature": 0.2},
        },
        timeout=90,
    )
    r.raise_for_status()
    return r.json()["message"]["content"]


def _call_groq(cfg, prompt):
    key = os.getenv("GROQ_API_KEY")
    if not key:
        raise RuntimeError("GROQ_API_KEY not set")
    r = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}"},
        json={
            "model": cfg["model"],
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
            "max_tokens": 300,
        },
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def summarize(events, analysis):
    cfg = config()
    if not events:
        return {"text": fallback_summary(events, analysis), "ok": False, "provider": "fallback", **cfg}
    prompt = build_prompt(events, analysis)
    try:
        if cfg["provider"] == "ollama":
            text = _call_ollama(cfg, prompt)
        elif cfg["provider"] == "groq":
            text = _call_groq(cfg, prompt)
        else:
            raise RuntimeError("LLM disabled")
        text = _clean(text)
        if not text:
            raise RuntimeError("empty model reply")
        return {"text": text, "ok": True, **cfg}
    except Exception as exc:  # network down, model missing, no key...
        return {
            "text": fallback_summary(events, analysis),
            "ok": False,
            "provider": "fallback",
            "model": cfg["model"],
            "params": cfg["params"],
            "error": str(exc)[:160],
        }
