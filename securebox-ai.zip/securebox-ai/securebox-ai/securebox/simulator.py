"""Scripted attack / normal scenarios for demos and tests."""
import time
from datetime import datetime

# (offset_seconds_from_start, event_type, detail)
SCENARIOS = {
    "normal_access": {
        "label": "Normal access",
        "events": [
            (0, "RFID_OK", "Card #A1 (custodian)"),
            (3, "DOOR_OPEN", "Door opened"),
            (40, "DOOR_CLOSE", "Door closed"),
        ],
    },
    "brute_force": {
        "label": "PIN brute force",
        "events": [
            (0, "PIN_FAIL", "PIN 1234"),
            (8, "PIN_FAIL", "PIN 0000"),
            (15, "PIN_FAIL", "PIN 1111"),
            (22, "PIN_FAIL", "PIN 4321"),
            (30, "PIN_FAIL", "PIN 2580"),
            (45, "DOOR_OPEN", "Door opened with no valid PIN"),
        ],
    },
    "forced_entry": {
        "label": "Forced entry + shutdown",
        "events": [
            (0, "TAMPER", "Tamper switch released"),
            (2, "DOOR_OPEN", "Door opened"),
            (50, "SHUTDOWN", "Computer lost power"),
            (70, "DOOR_CLOSE", "Door closed"),
        ],
    },
    "theft": {
        "label": "Box moved",
        "events": [
            (0, "MOVED", "Accelerometer: lifted"),
            (6, "SHUTDOWN", "Computer lost power"),
        ],
    },
    "rfid_probe": {
        "label": "RFID probing",
        "events": [
            (0, "RFID_DENIED", "Unknown card #F9"),
            (10, "RFID_DENIED", "Unknown card #07"),
            (19, "RFID_DENIED", "Unknown card #C3"),
        ],
    },
    "night_access": {
        "label": "Night access (authorised)",
        "night": True,
        "events": [
            (0, "PIN_OK", "PIN accepted"),
            (4, "DOOR_OPEN", "Door opened"),
            (90, "DOOR_CLOSE", "Door closed"),
        ],
    },
}


def run_scenario(store, name, now=None):
    if name not in SCENARIOS:
        raise KeyError(name)
    sc = SCENARIOS[name]
    now = time.time() if now is None else now
    span = max(o for o, _, _ in sc["events"])
    if sc.get("night"):
        d = datetime.fromtimestamp(now).replace(hour=2, minute=14, second=0, microsecond=0)
        start = d.timestamp()
    else:
        start = now - span
    ids = []
    for off, etype, detail in sc["events"]:
        ids.append(store.add(etype, detail, source="sim", ts=start + off))
    return ids
