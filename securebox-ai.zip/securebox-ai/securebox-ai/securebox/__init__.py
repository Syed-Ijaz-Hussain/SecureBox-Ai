"""SecureBox AI - physical security monitor with AI-assisted event analysis."""
