"""Deterministic rule engine: flags suspicious *combinations* of events.

The rules give an explainable risk score. The LLM then writes the human
summary on top of these findings, so the score never depends on model output.
"""
import time
from datetime import datetime

AUTH_OK = {"PIN_OK", "RFID_OK"}

SEVERITY_ORDER = {"info": 0, "medium": 1, "high": 2, "critical": 3}


def level_for(score):
    if score < 25:
        return "normal"
    if score < 50:
        return "elevated"
    if score < 75:
        return "high"
    return "critical"


def analyze(events, now=None, business_hours=(8, 18)):
    now = time.time() if now is None else now
    evs = sorted(events, key=lambda e: e["ts"])
    findings = []

    def add(rule, title, severity, points, why, ids):
        findings.append(
            {
                "rule": rule,
                "title": title,
                "severity": severity,
                "points": points,
                "why": why,
                "event_ids": ids,
            }
        )

    def recent_auth(ts, window=60):
        return any(e["type"] in AUTH_OK and ts - window <= e["ts"] <= ts for e in evs)

    # R1 - PIN brute force: 3+ wrong PINs inside 120 s
    fails = [e for e in evs if e["type"] == "PIN_FAIL"]
    best = []
    for i, f in enumerate(fails):
        burst = [x for x in fails[i:] if x["ts"] - f["ts"] <= 120]
        if len(burst) > len(best):
            best = burst
    if len(best) >= 3:
        pts = 45 if len(best) >= 5 else 30
        add(
            "BRUTE_FORCE",
            "PIN brute-force attempt",
            "critical" if len(best) >= 5 else "high",
            pts,
            f"{len(best)} wrong PINs within 2 minutes.",
            [e["id"] for e in best],
        )

    # R2 - RFID probing: 2+ denied cards inside 120 s
    denied = [e for e in evs if e["type"] == "RFID_DENIED"]
    for i, d in enumerate(denied):
        burst = [x for x in denied[i:] if x["ts"] - d["ts"] <= 120]
        if len(burst) >= 2:
            add(
                "RFID_PROBE",
                "Repeated unknown RFID cards",
                "high",
                20,
                f"{len(burst)} unrecognised cards within 2 minutes.",
                [e["id"] for e in burst],
            )
            break

    # R3 - door opened with no valid authentication in the previous 60 s
    opens = [e for e in evs if e["type"] == "DOOR_OPEN"]
    unauth = [o for o in opens if not recent_auth(o["ts"])]
    if unauth:
        add(
            "UNAUTH_OPEN",
            "Door opened without authentication",
            "critical",
            35,
            "No valid PIN or RFID scan in the 60 s before the door opened - "
            "possible forced entry or bypass.",
            [o["id"] for o in unauth],
        )

    # R4 - failed PINs followed by the door opening
    combo = []
    for o in unauth:
        prior = [f for f in fails if o["ts"] - 120 <= f["ts"] <= o["ts"]]
        if prior:
            combo.extend([prior[-1]["id"], o["id"]])
    if combo:
        add(
            "GUESS_THEN_OPEN",
            "Failed PINs followed by door opening",
            "high",
            20,
            "Wrong PINs were entered shortly before an unauthenticated opening.",
            combo,
        )

    # R5 - tamper switch
    tampers = [e for e in evs if e["type"] == "TAMPER"]
    if tampers:
        add(
            "TAMPER",
            "Tamper switch triggered",
            "critical",
            40,
            "The enclosure's tamper switch was activated.",
            [e["id"] for e in tampers],
        )

    # R6 - box moved
    moved = [e for e in evs if e["type"] == "MOVED"]
    if moved:
        add(
            "MOVED",
            "Box moved or lifted",
            "high",
            25,
            "Motion sensor reported the enclosure being moved.",
            [e["id"] for e in moved],
        )

    # R7 - shutdown soon after door/tamper = evidence-tampering pattern
    for s in [e for e in evs if e["type"] == "SHUTDOWN"]:
        trig = [
            e
            for e in evs
            if e["type"] in {"DOOR_OPEN", "TAMPER", "MOVED"}
            and s["ts"] - 300 <= e["ts"] <= s["ts"]
        ]
        if trig:
            add(
                "SHUTDOWN_AFTER_ACCESS",
                "Unexpected shutdown right after physical access",
                "critical",
                35,
                "Protected computer lost power within 5 minutes of the box "
                "being opened, tampered with or moved.",
                [trig[-1]["id"], s["id"]],
            )
        else:
            add(
                "SHUTDOWN",
                "Unexpected shutdown",
                "medium",
                15,
                "Protected computer lost power with no physical event nearby.",
                [s["id"]],
            )
        break

    # R8 - door left open
    last_open = None
    for e in evs:
        if e["type"] == "DOOR_OPEN":
            last_open = e
        elif e["type"] == "DOOR_CLOSE":
            last_open = None
    if last_open and now - last_open["ts"] > 120:
        add(
            "DOOR_LEFT_OPEN",
            "Door left open",
            "medium",
            15,
            "Door has been open for more than 2 minutes.",
            [last_open["id"]],
        )

    # R9 - access outside business hours
    lo, hi = business_hours
    odd = [
        e
        for e in evs
        if e["type"] in AUTH_OK | {"DOOR_OPEN"}
        and not (lo <= datetime.fromtimestamp(e["ts"]).hour < hi)
    ]
    if odd:
        add(
            "AFTER_HOURS",
            "Access outside business hours",
            "medium",
            10,
            f"Activity recorded outside {lo:02d}:00-{hi:02d}:00.",
            [e["id"] for e in odd],
        )

    findings.sort(key=lambda f: -f["points"])
    score = min(100, sum(f["points"] for f in findings))
    return {"score": score, "level": level_for(score), "findings": findings}


RECOMMENDATION = {
    "normal": "No action needed. Routine access.",
    "elevated": "Review the log at next opportunity and confirm the access was expected.",
    "high": "Contact the custodian now and verify who accessed the box.",
    "critical": "Treat as a security incident: secure the area, preserve the log, "
    "and notify the security officer immediately.",
}
