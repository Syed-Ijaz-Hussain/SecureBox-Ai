"""Tamper-evident event log: SQLite with a SHA-256 hash chain.

Every event stores the hash of the previous event, so editing or deleting a
past row breaks the chain and `verify()` reports exactly where.
"""
import hashlib
import sqlite3
import threading
import time

EVENT_TYPES = {
    "PIN_OK": "Correct PIN entered",
    "PIN_FAIL": "Wrong PIN entered",
    "RFID_OK": "Authorised RFID card scanned",
    "RFID_DENIED": "Unknown RFID card scanned",
    "DOOR_OPEN": "Door opened (magnetic sensor)",
    "DOOR_CLOSE": "Door closed (magnetic sensor)",
    "TAMPER": "Tamper switch triggered",
    "MOVED": "Box moved / lifted",
    "SHUTDOWN": "Protected computer lost power unexpectedly",
    "POWER_RESTORE": "Protected computer powered back on",
}

GENESIS = "0" * 64


def _digest(prev_hash, ts, etype, detail, source):
    raw = f"{prev_hash}|{ts:.3f}|{etype}|{detail}|{source}".encode()
    return hashlib.sha256(raw).hexdigest()


class EventStore:
    def __init__(self, path=":memory:"):
        self._lock = threading.Lock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS events ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, "
            "type TEXT NOT NULL, detail TEXT NOT NULL, source TEXT NOT NULL, "
            "prev_hash TEXT NOT NULL, hash TEXT NOT NULL)"
        )
        self._db.commit()

    def add(self, etype, detail="", source="sim", ts=None):
        if etype not in EVENT_TYPES:
            raise ValueError(f"unknown event type: {etype}")
        ts = time.time() if ts is None else float(ts)
        detail = str(detail)[:200]
        source = str(source)[:40]
        with self._lock:
            row = self._db.execute(
                "SELECT hash FROM events ORDER BY id DESC LIMIT 1"
            ).fetchone()
            prev = row["hash"] if row else GENESIS
            h = _digest(prev, ts, etype, detail, source)
            cur = self._db.execute(
                "INSERT INTO events (ts, type, detail, source, prev_hash, hash) "
                "VALUES (?,?,?,?,?,?)",
                (ts, etype, detail, source, prev, h),
            )
            self._db.commit()
            return cur.lastrowid

    def list(self, limit=200):
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in reversed(rows)]

    def clear(self):
        with self._lock:
            self._db.execute("DELETE FROM events")
            self._db.commit()

    def verify(self):
        """Return (ok, first_bad_id)."""
        with self._lock:
            rows = self._db.execute("SELECT * FROM events ORDER BY id").fetchall()
        prev = GENESIS
        for r in rows:
            expected = _digest(prev, r["ts"], r["type"], r["detail"], r["source"])
            if r["prev_hash"] != prev or r["hash"] != expected:
                return False, r["id"]
            prev = r["hash"]
        return True, None

    def _tamper_for_test(self, event_id, new_detail):
        with self._lock:
            self._db.execute(
                "UPDATE events SET detail=? WHERE id=?", (new_detail, event_id)
            )
            self._db.commit()
