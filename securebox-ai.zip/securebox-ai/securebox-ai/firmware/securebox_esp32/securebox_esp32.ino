/*
 * SecureBox AI - ESP32 firmware (hardware phase)
 *
 * Sends signed-by-token events to the SecureBox AI server (POST /api/events).
 *
 * Wiring (ESP32 DevKit):
 *   Magnetic reed switch (door)   GPIO 4  -> GND   (INPUT_PULLUP, closed door = LOW)
 *   Tamper micro-switch           GPIO 5  -> GND   (INPUT_PULLUP, enclosure closed = LOW)
 *   Buzzer (active)               GPIO 18 -> buzzer+ , buzzer- -> GND
 *   Status LED                    GPIO 2  (onboard)
 *   PC power sense                GPIO 34 <- 3.3 V-scaled USB 5 V line of the protected PC
 *                                 (use a 10k/20k divider; HIGH = computer powered)
 *   Optional RFID (MFRC522, SPI)  SDA 21, SCK 18->use 14 if buzzer shares, MOSI 23, MISO 19, RST 22
 *                                 (enable with #define USE_RFID, needs the MFRC522 library)
 *
 * Set WIFI_SSID, WIFI_PASS, SERVER_URL and DEVICE_TOKEN below. Do NOT commit real credentials.
 */
#include <WiFi.h>
#include <HTTPClient.h>

#define WIFI_SSID    "YOUR_WIFI"
#define WIFI_PASS    "YOUR_PASSWORD"
#define SERVER_URL   "http://192.168.1.50:5000/api/events"   // laptop running app.py
#define DEVICE_TOKEN "change-me"                              // must match DEVICE_TOKEN on server

// #define USE_RFID
#ifdef USE_RFID
  #include <SPI.h>
  #include <MFRC522.h>
  MFRC522 rfid(21, 22);
  const String AUTHORISED[] = {"A1B2C3D4"};  // replace with your card UIDs
#endif

const int PIN_DOOR = 4, PIN_TAMPER = 5, PIN_BUZZER = 18, PIN_LED = 2, PIN_PCPWR = 34;

bool lastDoorOpen = false, lastTamper = false, lastPcOn = true, alarmOn = false;
unsigned long alarmUntil = 0;

void sendEvent(const char* type, const char* detail) {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Token", DEVICE_TOKEN);
  String body = String("{\"type\":\"") + type + "\",\"detail\":\"" + detail + "\"}";
  http.POST(body);
  http.end();
}

void raiseAlarm(unsigned long ms) {
  alarmOn = true;
  alarmUntil = millis() + ms;
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_DOOR, INPUT_PULLUP);
  pinMode(PIN_TAMPER, INPUT_PULLUP);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_PCPWR, INPUT);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.println("\nWiFi OK");
#ifdef USE_RFID
  SPI.begin(); rfid.PCD_Init();
#endif
  lastDoorOpen = digitalRead(PIN_DOOR) == HIGH;
  lastTamper   = digitalRead(PIN_TAMPER) == HIGH;
  lastPcOn     = digitalRead(PIN_PCPWR) == HIGH;
}

void loop() {
  bool doorOpen = digitalRead(PIN_DOOR) == HIGH;      // magnet away = open
  bool tamper   = digitalRead(PIN_TAMPER) == HIGH;    // switch released = tamper
  bool pcOn     = digitalRead(PIN_PCPWR) == HIGH;

  if (doorOpen != lastDoorOpen) {
    sendEvent(doorOpen ? "DOOR_OPEN" : "DOOR_CLOSE", doorOpen ? "Door opened" : "Door closed");
    lastDoorOpen = doorOpen;
    delay(50);  // debounce
  }
  if (tamper && !lastTamper) {
    sendEvent("TAMPER", "Tamper switch released");
    raiseAlarm(10000);
  }
  lastTamper = tamper;

  if (!pcOn && lastPcOn)  { sendEvent("SHUTDOWN", "Computer lost power"); raiseAlarm(5000); }
  if (pcOn && !lastPcOn)  { sendEvent("POWER_RESTORE", "Computer powered on"); }
  lastPcOn = pcOn;

#ifdef USE_RFID
  if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    String uid;
    for (byte i = 0; i < rfid.uid.size; i++) { if (rfid.uid.uidByte[i] < 0x10) uid += "0"; uid += String(rfid.uid.uidByte[i], HEX); }
    uid.toUpperCase();
    bool ok = false;
    for (auto &a : AUTHORISED) if (a == uid) ok = true;
    sendEvent(ok ? "RFID_OK" : "RFID_DENIED", ok ? "Authorised card" : "Unknown card");
    if (!ok) raiseAlarm(2000);
    rfid.PICC_HaltA();
  }
#endif

  if (alarmOn && millis() < alarmUntil) {
    bool beat = (millis() / 250) % 2;
    digitalWrite(PIN_BUZZER, beat); digitalWrite(PIN_LED, beat);
  } else {
    alarmOn = false;
    digitalWrite(PIN_BUZZER, LOW);
    digitalWrite(PIN_LED, doorOpen ? HIGH : LOW);
  }
  delay(20);
}
