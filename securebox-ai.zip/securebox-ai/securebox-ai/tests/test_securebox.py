import time

import pytest

from app import create_app
from securebox import llm
from securebox.engine import analyze
from securebox.simulator import SCENARIOS, run_scenario
from securebox.store import EventStore

NOON = time.mktime(time.strptime("2026-10-15 12:00:00", "%Y-%m-%d %H:%M:%S"))


def run(name, now=NOON):
    s = EventStore()
    run_scenario(s, name, now=now)
    return s, analyze(s.list(), now=now)


def rules(a):
    return {f["rule"] for f in a["findings"]}


def test_normal_access_is_low_risk():
    _, a = run("normal_access")
    assert a["level"] == "normal" and a["score"] == 0


def test_brute_force_then_open_is_critical():
    _, a = run("brute_force")
    assert {"BRUTE_FORCE", "UNAUTH_OPEN", "GUESS_THEN_OPEN"} <= rules(a)
    assert a["level"] == "critical"


def test_forced_entry_and_shutdown_flagged_together():
    _, a = run("forced_entry")
    assert {"TAMPER", "UNAUTH_OPEN", "SHUTDOWN_AFTER_ACCESS"} <= rules(a)
    assert a["level"] == "critical"


def test_moved_plus_shutdown():
    _, a = run("theft")
    assert {"MOVED", "SHUTDOWN_AFTER_ACCESS"} <= rules(a)


def test_rfid_probe():
    _, a = run("rfid_probe")
    assert "RFID_PROBE" in rules(a)


def test_night_access_only_after_hours_flag():
    _, a = run("night_access")
    assert rules(a) == {"AFTER_HOURS"}
    assert a["level"] == "normal"


def test_two_wrong_pins_are_not_brute_force():
    s = EventStore()
    s.add("PIN_FAIL", ts=NOON - 10)
    s.add("PIN_FAIL", ts=NOON - 5)
    assert "BRUTE_FORCE" not in rules(analyze(s.list(), now=NOON))


def test_door_left_open():
    s = EventStore()
    s.add("PIN_OK", ts=NOON - 400)
    s.add("DOOR_OPEN", ts=NOON - 395)
    assert "DOOR_LEFT_OPEN" in rules(analyze(s.list(), now=NOON))


def test_hash_chain_detects_edit():
    s, _ = run("normal_access")
    assert s.verify() == (True, None)
    s._tamper_for_test(2, "edited by attacker")
    ok, bad = s.verify()
    assert not ok and bad == 2


def test_unknown_event_type_rejected():
    with pytest.raises(ValueError):
        EventStore().add("NOPE")


def test_llm_fallback_is_honest(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "none")
    s, a = run("brute_force")
    r = llm.summarize(s.list(), a)
    assert r["ok"] is False and r["provider"] == "fallback"
    assert "SUMMARY:" in r["text"]


def test_llm_uses_model_when_available(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "ollama")
    monkeypatch.setattr(llm, "_call_ollama", lambda c, p: "<think>x</think>SUMMARY: ok\nASSESSMENT: bad\nACTION: act")
    s, a = run("brute_force")
    r = llm.summarize(s.list(), a)
    assert r["ok"] is True and r["text"].startswith("SUMMARY: ok")


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("DEVICE_TOKEN", "secret")
    monkeypatch.setenv("LLM_PROVIDER", "none")
    return create_app(":memory:").test_client()


def test_api_device_auth(client):
    assert client.post("/api/events", json={"type": "TAMPER"}).status_code == 401
    ok = client.post("/api/events", json={"type": "TAMPER", "detail": "x"}, headers={"X-Device-Token": "secret"})
    assert ok.status_code == 201
    bad = client.post("/api/events", json={"type": "BOGUS"}, headers={"X-Device-Token": "secret"})
    assert bad.status_code == 400


def test_api_scenario_flow(client):
    for name in SCENARIOS:
        assert client.post("/api/simulate", json={"scenario": name}).status_code == 201
    st = client.get("/api/state").get_json()
    assert st["chain"]["ok"] and st["events"]
    assert client.post("/api/summarize").get_json()["text"]
    client.post("/api/reset")
    assert client.get("/api/state").get_json()["events"] == []
    assert client.get("/").status_code == 200
