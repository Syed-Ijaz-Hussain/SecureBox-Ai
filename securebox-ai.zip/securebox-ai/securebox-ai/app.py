"""SecureBox AI - Flask API + dashboard."""
import hmac
import os

from flask import Flask, jsonify, render_template, request

from securebox import llm
from securebox.engine import analyze
from securebox.simulator import SCENARIOS, run_scenario
from securebox.store import EVENT_TYPES, EventStore


def create_app(db_path=None):
    app = Flask(__name__)
    store = EventStore(db_path or os.getenv("SECUREBOX_DB", "securebox.db"))
    device_token = os.getenv("DEVICE_TOKEN", "")

    @app.get("/")
    def index():
        return render_template(
            "index.html",
            scenarios=[(k, v["label"]) for k, v in SCENARIOS.items()],
            event_types=list(EVENT_TYPES),
        )

    @app.get("/api/state")
    def state():
        events = store.list()
        ok, bad = store.verify()
        return jsonify(
            events=events,
            analysis=analyze(events),
            chain={"ok": ok, "first_bad_id": bad},
            llm=llm.config(),
        )

    @app.post("/api/events")
    def device_event():
        """Endpoint for the ESP32. Requires X-Device-Token when DEVICE_TOKEN is set."""
        if device_token:
            sent = request.headers.get("X-Device-Token", "")
            if not hmac.compare_digest(sent, device_token):
                return jsonify(error="unauthorized"), 401
        body = request.get_json(silent=True) or {}
        try:
            eid = store.add(body.get("type", ""), body.get("detail", ""), source="esp32")
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        return jsonify(id=eid), 201

    @app.post("/api/manual")
    def manual():
        body = request.get_json(silent=True) or {}
        try:
            eid = store.add(body.get("type", ""), body.get("detail", "Manual demo event"), source="demo")
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        return jsonify(id=eid), 201

    @app.post("/api/simulate")
    def simulate():
        name = (request.get_json(silent=True) or {}).get("scenario", "")
        if name not in SCENARIOS:
            return jsonify(error="unknown scenario"), 400
        return jsonify(ids=run_scenario(store, name)), 201

    @app.post("/api/summarize")
    def summarize():
        events = store.list()
        return jsonify(llm.summarize(events, analyze(events)))

    @app.post("/api/reset")
    def reset():
        store.clear()
        return jsonify(ok=True)

    return app


if __name__ == "__main__":
    create_app().run(
        host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "5000"))
    )
