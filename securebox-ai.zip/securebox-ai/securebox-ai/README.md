# 🔐 SecureBox AI

**A physical-security monitor for sensitive computers and evidence cabinets. Sensors log what happens to the box, a rule engine flags suspicious *combinations* of events, and a small open-weight AI model explains the incident in plain English.**

> Hacktoberfest Lahore 2026 · Riphah International University · Build / Open / Share

## Problem

A computer or evidence-storage cabinet can be opened, moved or accessed without authorisation, and nobody notices until the damage is done. A single event (a door opening) is often harmless; the *sequence* (five wrong PINs, then the door opens, then the computer loses power) is the real signal.

## Solution

- **Event log** with a SHA-256 hash chain, so editing or deleting history is detectable (the dashboard shows "log integrity: verified").
- **Rule engine** (deterministic, explainable) that scores risk 0-100 and flags combinations such as *failed PINs → unauthenticated door open → unexpected shutdown*.
- **AI summary**: an open-weight model (≤ 8B) reads the log and the rule findings and writes a summary, an assessment and a recommended action.
- **Live dashboard** with a virtual box (door, LED, buzzer, optional browser siren) and one-click attack scenarios for demos.
- **ESP32 firmware** for the real hardware phase: reed switch, tamper switch, buzzer, PC power sense, optional RFID.

## AI component (disclosure)

| Item | Value |
|---|---|
| Default model | **Qwen3-4B** (`qwen3:4b`), 4 billion parameters |
| Runtime | **Ollama**, running locally |
| Alternative | **Llama 3.1 8B Instant** (`llama-3.1-8b-instant`), 8 billion parameters, via **Groq API** (`LLM_PROVIDER=groq`) |
| Role | Core feature: turns the event sequence and rule findings into the incident summary, assessment and action shown to the operator. It is prompted with only the logged events and told not to invent any. |
| Design choice | The risk **score** comes from the rule engine, not the model, so it is reproducible and explainable. The model provides the narrative. |
| Failure behaviour | If the model is unreachable, the app shows a template summary **and labels it "Model unavailable"**. It never presents fallback text as AI output. |

Check provider availability before relying on a hosted model. Both models are within the 8B limit; the model name and size are displayed in the dashboard header.

## Quick start

```bash
git clone <your-repo-url> && cd securebox-ai
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Option A - local model (recommended)
ollama pull qwen3:4b

# Option B - Groq (8B hosted)
export LLM_PROVIDER=groq
export GROQ_API_KEY=your_key_here      # never commit this

python app.py                           # http://localhost:5000
```

Environment variable names are listed in `.env.example`. Run the tests with `python -m pytest -q`.

### Demo in 60 seconds

1. Open the dashboard and click **Normal access**: score stays 0, green LED.
2. Click **PIN brute force**: 5 wrong PINs, then the door opens with no PIN. The box shakes red, the buzzer state flips to ALARM, and the AI explains it.
3. Click **Forced entry + shutdown**: tamper, door, power loss. The engine flags the evidence-tampering pattern.
4. Tick **Sound alarm in browser** to hear the siren.
5. Show the integrity badge, then explain that editing the DB would turn it red.

## Architecture

```mermaid
flowchart LR
  subgraph Box[Physical box]
    S[Reed switch / tamper switch / PC power sense / RFID]
    E[ESP32 + buzzer]
    S --> E
  end
  E -- "POST /api/events + X-Device-Token" --> B[Flask backend]
  SIM[Scenario simulator] --> B
  B --> L[(SQLite hash-chained log)]
  L --> R[Rule engine]
  R --> M[AI model: Qwen3-4B Ollama or Llama 3.1 8B Groq]
  R --> UI[Dashboard]
  M --> UI
  B --> UI
```

## Data flow

```mermaid
flowchart LR
  A[Sensor or simulated event] --> V((Validate + hash-chain))
  V --> D[(Event log)]
  D --> RE((Rule engine))
  RE -->|score + findings| UI[Dashboard]
  D --> P((Prompt builder))
  RE --> P
  P --> M[AI model]
  M -->|summary, assessment, action| UI
```

## Sequence: forced entry

```mermaid
sequenceDiagram
  participant E as ESP32
  participant S as Backend
  participant R as Rule engine
  participant M as AI model
  participant U as Operator
  E->>S: TAMPER
  E->>S: DOOR_OPEN
  E->>S: SHUTDOWN
  S->>R: analyse(events)
  R-->>S: critical, 3 findings
  U->>S: Analyse with AI
  S->>M: log + findings
  M-->>S: summary, assessment, action
  S-->>U: summary + alarm state
```

## Detection rules

| Rule | Trigger | Points |
|---|---|---|
| BRUTE_FORCE | ≥3 wrong PINs in 2 min (≥5 = critical) | 30 / 45 |
| RFID_PROBE | ≥2 unknown cards in 2 min | 20 |
| UNAUTH_OPEN | Door opens with no valid PIN/RFID in the prior 60 s | 35 |
| GUESS_THEN_OPEN | Wrong PINs shortly before an unauthenticated opening | 20 |
| TAMPER | Tamper switch triggered | 40 |
| MOVED | Box lifted or moved | 25 |
| SHUTDOWN_AFTER_ACCESS | Power loss within 5 min of door/tamper/move | 35 |
| SHUTDOWN | Power loss with no physical cause nearby | 15 |
| DOOR_LEFT_OPEN | Open > 2 min | 15 |
| AFTER_HOURS | Access outside 08:00-18:00 | 10 |

Levels: <25 normal · <50 elevated · <75 high · ≥75 critical. Score is capped at 100.

## Hardware phase (ESP32)

Firmware: `firmware/securebox_esp32/securebox_esp32.ino`

| Part | Pin |
|---|---|
| Magnetic door (reed) switch | GPIO 4 |
| Tamper micro-switch | GPIO 5 |
| Buzzer | GPIO 18 |
| PC power sense (via 10k/20k divider from USB 5 V) | GPIO 34 |
| Optional MFRC522 RFID | SPI (see sketch header) |

Set Wi-Fi, server URL and `DEVICE_TOKEN` in the sketch (use placeholders in git; never commit real credentials). The server rejects device posts with a wrong token. **The firmware has not been compiled or run on real hardware yet; it is the planned hardware phase.**

## Testing and findings

Run: `python -m pytest -q` → **14 passed**.

| Scenario | Input | Expected | Actual | Status |
|---|---|---|---|---|
| Normal access | RFID_OK → DOOR_OPEN → DOOR_CLOSE | score 0, normal | score 0, normal | PASS |
| Brute force | 5 PIN_FAIL → DOOR_OPEN | BRUTE_FORCE + UNAUTH_OPEN + GUESS_THEN_OPEN, critical | as expected | PASS |
| Forced entry | TAMPER → DOOR_OPEN → SHUTDOWN | TAMPER + UNAUTH_OPEN + SHUTDOWN_AFTER_ACCESS, critical | as expected | PASS |
| Box moved | MOVED → SHUTDOWN | MOVED + SHUTDOWN_AFTER_ACCESS | as expected | PASS |
| RFID probing | 3 × RFID_DENIED | RFID_PROBE | as expected | PASS |
| Night access | 02:14 PIN_OK → open → close | only AFTER_HOURS, level normal | as expected | PASS |
| 2 wrong PINs | 2 × PIN_FAIL | no brute-force flag | no flag | PASS |
| Door left open | open, no close, 6 min | DOOR_LEFT_OPEN | as expected | PASS |
| Log tampering | edit a stored row | verify() fails at that row | fails at row 2 | PASS |
| Device auth | POST without/with wrong token | 401 / 400 | as expected | PASS |
| Model fallback | model disabled | honest fallback, `ok=false` | as expected | PASS |
| Model path | model call mocked | reply used, `<think>` stripped | as expected | PASS |

### Known limitations

- The **live model call** (Ollama / Groq) is covered by a mocked test only; it was not run against a real model in the test environment. Try it on your machine before the demo.
- Small models can occasionally ignore the three-line format or over-state risk; the rule engine's score is the source of truth.
- Rules use fixed thresholds and local server time; no per-site tuning yet.
- The hash chain proves *tampering happened* but does not prevent a DB owner from rewriting the whole chain; for production, ship hashes to a separate write-only store.
- The dashboard has no login (demo only). The device endpoint is token-protected, but traffic is plain HTTP on the LAN.
- Hardware firmware is untested on a physical board.

## Team and contributions

| Name | Contribution |
|---|---|
| _Your name_ | _Software, rule engine, dashboard_ |
| _Teammate_ | _Electronics, firmware_ |

## Licence and acknowledgements

MIT licensed (see `LICENSE`). Built with Flask, Requests, Ollama, Qwen3 (Alibaba Cloud, Apache-2.0), Meta Llama 3.1 (Llama 3.1 Community License) and Groq. The MFRC522 library is used optionally in the firmware. AI-assisted development tools were used to help write this code; the team is responsible for understanding and presenting it.
